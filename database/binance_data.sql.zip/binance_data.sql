-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 29, 2021 at 11:29 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `binance_data`
--

-- --------------------------------------------------------

--
-- Table structure for table `symbol_historical_1day`
--

CREATE TABLE `symbol_historical_1day` (
  `open_time` datetime NOT NULL,
  `symbol` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `open` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `high` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `low` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `close` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `volume` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_of_trade` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `symbol_historical_1hour`
--

CREATE TABLE `symbol_historical_1hour` (
  `open_time` datetime NOT NULL,
  `symbol` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `open` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `high` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `low` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `close` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `volume` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_of_trade` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `symbol_historical_1minute`
--

CREATE TABLE `symbol_historical_1minute` (
  `open_time` datetime NOT NULL,
  `symbol` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `open` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `high` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `low` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `close` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `volume` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_of_trade` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `symbol_historical_1month`
--

CREATE TABLE `symbol_historical_1month` (
  `open_time` datetime NOT NULL,
  `symbol` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `open` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `high` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `low` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `close` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `volume` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_of_trade` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `symbol_historical_1week`
--

CREATE TABLE `symbol_historical_1week` (
  `open_time` datetime NOT NULL,
  `symbol` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `open` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `high` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `low` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `close` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `volume` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_of_trade` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `symbol_historical_2hour`
--

CREATE TABLE `symbol_historical_2hour` (
  `open_time` datetime NOT NULL,
  `symbol` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `open` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `high` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `low` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `close` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `volume` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_of_trade` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `symbol_historical_3day`
--

CREATE TABLE `symbol_historical_3day` (
  `open_time` datetime NOT NULL,
  `symbol` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `open` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `high` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `low` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `close` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `volume` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_of_trade` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `symbol_historical_3minute`
--

CREATE TABLE `symbol_historical_3minute` (
  `open_time` datetime NOT NULL,
  `symbol` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `open` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `high` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `low` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `close` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `volume` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_of_trade` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `symbol_historical_4hour`
--

CREATE TABLE `symbol_historical_4hour` (
  `open_time` datetime NOT NULL,
  `symbol` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `open` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `high` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `low` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `close` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `volume` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_of_trade` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `symbol_historical_5minute`
--

CREATE TABLE `symbol_historical_5minute` (
  `open_time` datetime NOT NULL,
  `symbol` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `open` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `high` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `low` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `close` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `volume` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_of_trade` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `symbol_historical_6hour`
--

CREATE TABLE `symbol_historical_6hour` (
  `open_time` datetime NOT NULL,
  `symbol` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `open` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `high` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `low` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `close` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `volume` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_of_trade` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `symbol_historical_8hour`
--

CREATE TABLE `symbol_historical_8hour` (
  `open_time` datetime NOT NULL,
  `symbol` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `open` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `high` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `low` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `close` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `volume` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_of_trade` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `symbol_historical_12hour`
--

CREATE TABLE `symbol_historical_12hour` (
  `open_time` datetime NOT NULL,
  `symbol` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `open` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `high` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `low` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `close` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `volume` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_of_trade` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `symbol_historical_15minute`
--

CREATE TABLE `symbol_historical_15minute` (
  `open_time` datetime NOT NULL,
  `symbol` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `open` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `high` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `low` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `close` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `volume` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_of_trade` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `symbol_historical_30minute`
--

CREATE TABLE `symbol_historical_30minute` (
  `open_time` datetime NOT NULL,
  `symbol` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `open` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `high` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `low` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `close` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `volume` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_of_trade` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `symbol_historical_1day`
--
ALTER TABLE `symbol_historical_1day`
  ADD PRIMARY KEY (`open_time`,`symbol`);

--
-- Indexes for table `symbol_historical_1hour`
--
ALTER TABLE `symbol_historical_1hour`
  ADD PRIMARY KEY (`open_time`,`symbol`);

--
-- Indexes for table `symbol_historical_1minute`
--
ALTER TABLE `symbol_historical_1minute`
  ADD PRIMARY KEY (`open_time`,`symbol`);

--
-- Indexes for table `symbol_historical_1month`
--
ALTER TABLE `symbol_historical_1month`
  ADD PRIMARY KEY (`open_time`,`symbol`);

--
-- Indexes for table `symbol_historical_1week`
--
ALTER TABLE `symbol_historical_1week`
  ADD PRIMARY KEY (`open_time`,`symbol`);

--
-- Indexes for table `symbol_historical_2hour`
--
ALTER TABLE `symbol_historical_2hour`
  ADD PRIMARY KEY (`open_time`,`symbol`);

--
-- Indexes for table `symbol_historical_3day`
--
ALTER TABLE `symbol_historical_3day`
  ADD PRIMARY KEY (`open_time`,`symbol`);

--
-- Indexes for table `symbol_historical_3minute`
--
ALTER TABLE `symbol_historical_3minute`
  ADD PRIMARY KEY (`open_time`,`symbol`);

--
-- Indexes for table `symbol_historical_4hour`
--
ALTER TABLE `symbol_historical_4hour`
  ADD PRIMARY KEY (`open_time`,`symbol`);

--
-- Indexes for table `symbol_historical_5minute`
--
ALTER TABLE `symbol_historical_5minute`
  ADD PRIMARY KEY (`open_time`,`symbol`);

--
-- Indexes for table `symbol_historical_6hour`
--
ALTER TABLE `symbol_historical_6hour`
  ADD PRIMARY KEY (`open_time`,`symbol`);

--
-- Indexes for table `symbol_historical_8hour`
--
ALTER TABLE `symbol_historical_8hour`
  ADD PRIMARY KEY (`open_time`,`symbol`);

--
-- Indexes for table `symbol_historical_12hour`
--
ALTER TABLE `symbol_historical_12hour`
  ADD PRIMARY KEY (`open_time`,`symbol`);

--
-- Indexes for table `symbol_historical_15minute`
--
ALTER TABLE `symbol_historical_15minute`
  ADD PRIMARY KEY (`open_time`,`symbol`);

--
-- Indexes for table `symbol_historical_30minute`
--
ALTER TABLE `symbol_historical_30minute`
  ADD PRIMARY KEY (`open_time`,`symbol`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
